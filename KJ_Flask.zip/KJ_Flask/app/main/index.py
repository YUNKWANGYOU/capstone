from flask import Blueprint, request, render_template, flash, redirect, url_for
from flask import current_app as app
from app.module import dbModule
from flask_bootstrap import Bootstrap

# 추가할 모듈이 있다면 추가

main = Blueprint('main', __name__, url_prefix='/')

@main.route('/main', methods=['GET'])
def index():
      data = dbModule.DataHandler()
      data.execute("select * from Sensor_Data")
      print("Time : " ,data.time_0)
      print("Temperature : " ,data.temperature_0)
      print("Humidity : " ,data.humidity_0)
      print("Heart Rate : " ,data.heart_0)
      data.close()
      testData = 'testData array'

      return render_template('/main/index.html',Time_50 = data.time_50,
                                                Temperature_50 = data.temperature_50,
                                                Humidity_50 = data.humidity_50,
                                                Heart_Rate_50 = data.heart_50,

                                                Time_40 = data.time_40,
                                                Temperature_40 = data.temperature_40,
                                                Humidity_40 = data.humidity_40,
                                                Heart_Rate_40 = data.heart_40,

                                                Time_30 = data.time_30,
                                                Temperature_30 = data.temperature_30,
                                                Humidity_30 = data.humidity_30,
                                                Heart_Rate_30 = data.heart_30,

                                                Time_20 = data.time_20,
                                                Temperature_20 = data.temperature_20,
                                                Humidity_20 = data.humidity_20,
                                                Heart_Rate_20 = data.heart_20,

                                                Time_10 = data.time_10,
                                                Temperature_10 = data.temperature_10,
                                                Humidity_10 = data.humidity_10,
                                                Heart_Rate_10 = data.heart_10,

                                                Time_0 = data.time_0,
                                                Temperature_0 = data.temperature_0,
                                                Humidity_0 = data.humidity_0,
                                                Heart_Rate_0 = data.heart_0)
